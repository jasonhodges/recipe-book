import { Component } from '@angular/core';

@Component({
  selector: 'recipe-book-app',
  templateUrl: 'recipe-book.component.html'
})
export class RecipeBookAppComponent {
}
